
%Detect objects using Viola-Jones Algorithm

%To detect Face
vid = webcam();



%%
n=1;
Nfrm_movie=20;

%  s=serial('com5');
 % fopen(s);


%signal='No signal';
for k = 1:Nfrm_movie
    
    
     % Getting Image
     I = snapshot(vid);
%I=imread('C:\Users\Admin\Desktop\share\cam_1.jpg');
subplot(1,3,1),imshow(I);
title('Captured image');

     FDetect = vision.CascadeObjectDetector;
 I(:,:,1)=adapthisteq(I(:,:,1));
 I(:,:,2)=adapthisteq(I(:,:,2));
 I(:,:,3)=adapthisteq(I(:,:,3));
  subplot(1,3,2),imshow(I);
     title('Enhanced image');



%Returns Bounding Box values based on number of objects
BB = step(FDetect,I);
if size(BB,1)>=1 

F=imcrop(I,BB(1,:));
imwrite(F,['frame\',num2str(n),'.jpg']);n=n+1;
F=imresize(F,[300,300]);
%% NOSE DETECTION:
subplot(1,3,3),imshow(F);
title('Detected ');



[a, E1]=selectsignal1(F);

 
% F=imresize(F,[300 300]);

a
 if a >0.6

    disp('Authenticated person ');
    signal='A';
 else
     disp('Face  Detected');
 signal='M';
   
end


% figure,imshow(Eyes);
% flushdata(vid);
else
   disp('Face not detected');  
 %signal='N';
end
 % fprintf(s,signal);
 pause(0.03);
end

%% Stopping Video Camera
   %fclose(s);
 %stop(vid)
delete(vid)

